document.querySelector('.Agregar_Producto').addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector('.agregar-producto-menu').classList.toggle('show');
});